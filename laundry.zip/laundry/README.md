# phpnative-aplikasi-laundry

Silahkan buat database dengan nama ujikom_laundry dan import db nya
