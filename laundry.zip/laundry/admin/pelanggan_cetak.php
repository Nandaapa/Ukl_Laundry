<!DOCTYPE html>

<html>

<head>

<title>CETAK DATA PELANGGAN</title>

</head>

<body>

<center>

<h2>DATA PELANGGAN</h2>

<h4>LAUNDRY DAFFA</h4>

</center>

<?php

require 'functions.php';

?>

<table border="1"style="width: 100%">
<tr>
                                <th width="5%">NO</th>
                                <th>Nama</th>
                                <th>Alamat</th>
                                <th>JK</th>
                                <th>Telepon</th>
                                
                            </tr>
<?php

$no =1;

$sql=mysqli_query($conn,"select * from member");

while($data=mysqli_fetch_array($sql)){

?>

<tr>

<td><?php echo$no++;?></td>

<td><?= $data['nama_member'] ?></td>
                                    <td><?= $data['alamat_member'] ?></td>
                                    <td><?= $data['jenis_kelamin'] ?></td>
                                    <td><?= $data['telp_member'] ?></td>
</tr>

<?php
}
?>

</table>

<script>

window.print();

</script>

</body>

</html>