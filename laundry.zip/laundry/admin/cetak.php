

<!DOCTYPE html>

<html>

<head>

<title>cetak</title>

</head>

<body>

<center>

<h2>DATA LAPORAN Transaksi</h2>

<h4>Laundry Daffa</h4>

</center>

<table border="1"style="width: 100%">

<tr>

<th width="1%">No</th>

                                
                                <th>Member</th>
                                <th>Status</th>
                                <th>Pemabayaran</th>
                                <th>Total Harga</th>

</tr>

<?php

$no =1;
require 'functions.php';
$query = "SELECT transaksi.*,member.nama_member , detail_transaksi.total_harga FROM transaksi INNER JOIN member ON member.id_member = transaksi.member_id INNER JOIN detail_transaksi ON detail_transaksi.transaksi_id = transaksi.id_transaksi ";
$data = ambildata($conn,$query);

while($data=mysqli_fetch_array($query)){

?>

<tr>

<td><?php echo$no++;?></td>
<td><?= $data['nama_member'] ?></td>
                                    <td><?= $data['status'] ?></td>
                                    <td><?= $data['status_bayar'] ?></td>
                                    <td><?= $data['total_harga'] ?></td>
                                   
</tr>

<?php
}
?>

</table>

<script>

window.print();

</script>

</body>

</html>